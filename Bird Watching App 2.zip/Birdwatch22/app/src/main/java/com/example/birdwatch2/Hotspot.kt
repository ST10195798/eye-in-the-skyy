package com.example.birdwatch2

data class Hotspot(
    val locId: String,
    val lat: Double,
    val lng: Double,
    val locName: String
)
