package com.example.birdwatch2

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView



class ObservationsAdapter(context: Context, private val observations: List<BirdObservations>) :
    ArrayAdapter<BirdObservations>(context, 0, observations) {

    @SuppressLint("SetTextI18n")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.observation_list_item, parent, false)
        val observation = observations[position]

        // Populate data into the custom layout views
        view.findViewById<TextView>(R.id.observationTitleTextView).text = "Species: ${observation.speciesName}"
        view.findViewById<TextView>(R.id.observationDetailsTextView).text = "Lat: ${observation.latitude}, Lng: ${observation.longitude}"
        view.findViewById<TextView>(R.id.observationTimestampTextView).text = "Time: ${observation.observationTime}"

        return view
    }
}

