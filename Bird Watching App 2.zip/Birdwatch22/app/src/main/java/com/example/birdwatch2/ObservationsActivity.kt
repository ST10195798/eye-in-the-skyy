package com.example.birdwatch2

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot

class ObservationsActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_observations)

        db = FirebaseFirestore.getInstance()

        val listView: ListView = findViewById(R.id.observationsListView)

        // Fetch observations from Firestore
        fetchObservations { observations ->
            if (observations.isNotEmpty()) {
                // Use custom adapter with observations data
                val adapter = ObservationsAdapter(this, observations)
                listView.adapter = adapter
            } else {
                // Display "No observations available" in a simple list item
                val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("No observations available"))
                listView.adapter = adapter
            }
        }
    }

    private fun fetchObservations(callback: (List<BirdObservations>) -> Unit) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        db.collection("users")
            .document(userId ?: "")
            .collection("observations")
            .get()
            .addOnSuccessListener { result ->
                val observations = result.mapNotNull { document ->
                    val latitude = document.getDouble("latitude") ?: return@mapNotNull null
                    val longitude = document.getDouble("longitude") ?: return@mapNotNull null
                    val observationTime = document.getLong("observationTime") ?: return@mapNotNull null
                    val speciesName = document.getString("speciesName") ?: return@mapNotNull null

                    BirdObservations(speciesName, observationTime, latitude, longitude)
                }
                callback(observations)
            }
            .addOnFailureListener { exception ->
                Log.w("ObservationsActivity", "Error getting observations: ", exception)
                Toast.makeText(this, "Error loading observations", Toast.LENGTH_SHORT).show()
                callback(emptyList())
            }
    }
}



