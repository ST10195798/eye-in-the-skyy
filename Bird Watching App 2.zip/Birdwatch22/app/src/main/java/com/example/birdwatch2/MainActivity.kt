package com.example.birdwatch2

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.Toast // Changes made here: Added Toast import for map loading feedback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PolylineOptions
import com.google.maps.android.PolyUtil
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import com.google.android.gms.maps.model.BitmapDescriptorFactory
//
import android.Manifest
import android.util.Log
import android.widget.EditText
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore


class MainActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private val observations = mutableListOf<BirdObservations>()
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var currentLocation: LatLng? = null
    private val REQUEST_LOCATION_PERMISSION = 1
    private var useMetric: Boolean = true
    private var maxDistance: Int = 10 // Default distance is 10
    private lateinit var AI : Button


    //
    val firestore = FirebaseFirestore.getInstance()

    // Assuming user is authenticated
    val user = FirebaseAuth.getInstance().currentUser
    val userId = user?.uid



    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        AI = findViewById(R.id.AI)

        // Assuming you have a method to fetch students from Firebase
        AI.setOnClickListener {
            val homeIntent = Intent(this, AIActivity::class.java)
            startActivity(homeIntent)
        }
        // Retrieve settings from Intent
        val intent = intent
        useMetric = intent.getBooleanExtra("useMetric", true) // Default to true (metric system)
        maxDistance = intent.getIntExtra("maxDistance", 10) // Default to 10 km

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        val settingsButton: Button = findViewById(R.id.settingsButton)
        val viewObservationsButton: Button = findViewById(R.id.viewObservationsButton)
        val saveObservationButton: Button = findViewById(R.id.saveObservationButton)

        settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
            // Changes made here: Added redirection to SettingsActivity for user settings
        }
        saveObservationButton.setOnClickListener {
            // Log to check if the button click is working
            Log.d("MainActivity", "Save Observation button clicked!")

            // Assuming you get species name from the input EditText
            val speciesName = findViewById<EditText>(R.id.speciesNameInput).text.toString()
            if (speciesName.isNotEmpty()) {
                // Save the observation
                saveObservation(speciesName)

            } else {
                Toast.makeText(this, "Please enter a species name", Toast.LENGTH_SHORT).show()
            }
        }

        viewObservationsButton.setOnClickListener {
            val intent = Intent(this, ObservationsActivity::class.java)
            //LOG
            Log.d("MainActivity", "Observations to pass: $observations")

            intent.putParcelableArrayListExtra("observations", ArrayList(observations))
            startActivity(intent)
            // Changes made here: Added redirection to ObservationsActivity to view saved observations
        }
        //Calling Methods


        centerMapOnLatestObservation()
        loadObservations()
        displaySavedObservations()

        // Changes made here: Inform users that map is loading for better UX
        Toast.makeText(this, "Loading map...", Toast.LENGTH_SHORT).show()
    }
    private fun applySettingsToMap() {
        if (useMetric) {
            Log.d("MapActivity", "Using metric system (km)")
        } else {
            Log.d("MapActivity", "Using imperial system (miles)")
        }

        // Additional map-related adjustments can go here, e.g., maxDistance
    }
    private fun filterHotspotsByDistance(maxDistance: Int) {
        // Your logic to filter hotspots based on maxDistance
        // Assuming you already have a list of hotspots
    }
    private fun saveObservation(speciesName: String) {
        val observation = BirdObservations(
            speciesName = speciesName,
            observationTime = System.currentTimeMillis(),
            latitude = mMap.cameraPosition.target.latitude,
            longitude = mMap.cameraPosition.target.longitude
        )

        userId?.let { uid ->
            firestore.collection("users").document(uid)
                .collection("observations").add(observation)
                .addOnSuccessListener {
                    Toast.makeText(this, "Observation saved!", Toast.LENGTH_SHORT).show()

                    // Immediately add the observation marker on the map
                    val observationLocation = LatLng(observation.latitude, observation.longitude)
                    mMap.addMarker(
                        MarkerOptions()
                            .position(observationLocation)
                            .title(observation.speciesName)
                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.my_observation_img))
                    )

                    // Optionally, center map on the new observation
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(observationLocation, 12f))
                }
                .addOnFailureListener { e ->
                    Log.w("MainActivity", "Error saving observation", e)
                }
        }
    }
    fun loadObservations() {
        val user = FirebaseAuth.getInstance().currentUser
        val userId = user?.uid

        userId?.let {
            firestore.collection("users").document(it)
                .collection("observations")
                .get()
                .addOnSuccessListener { result ->
                    val observations = mutableListOf<BirdObservations>()
                    for (document in result) {
                        val observation = document.toObject(BirdObservations::class.java)
                        observations.add(observation)
                    }

                    // Display observations on the map
                    for (observation in observations) {
                        val observationLocation = LatLng(observation.latitude, observation.longitude)
                        mMap.addMarker(MarkerOptions().position(observationLocation).title(observation.speciesName).icon(BitmapDescriptorFactory.fromResource(R.drawable.my_observation_img)))
                        // Optionally, zoom in on the marker after saving the observation
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(observationLocation, 12f))
                        Toast.makeText(this, "Observation saved!", Toast.LENGTH_SHORT).show()
                    }
                }
                .addOnFailureListener { e ->
                    Log.w("MainActivity", "Error loading observations", e)
                }
        }
    }



    @SuppressLint("PotentialBehaviorOverride", "MissingPermission")
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        // Apply settings to map behavior
        applySettingsToMap()

        // Example: If you need to filter hotspots based on maxDistance
        filterHotspotsByDistance(maxDistance)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Check location permissions
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.lastLocation.addOnCompleteListener(this) { task ->
                val location = task.result
                if (location != null) {
                    currentLocation = LatLng(location.latitude, location.longitude)
                    mMap.addMarker(MarkerOptions().position(currentLocation!!).title("Current Location"))
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLocation!!, 12f))
                    //added here while passing values to parameters
                    fetchHotspots(location.latitude, location.longitude)
                } else {
                    val defaultLocation = LatLng(-34.0, 151.0)
                    currentLocation = defaultLocation
                    mMap.addMarker(MarkerOptions().position(defaultLocation).title("Default Location"))
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 12f))
                }
            }
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), REQUEST_LOCATION_PERMISSION)
        }


        //removed fetchHotspot function call here

        mMap.setOnMarkerClickListener { marker ->
            val destination = marker.position
            currentLocation?.let { location ->
                fetchRoute(location.latitude, location.longitude, destination.latitude, destination.longitude)
            } ?: Toast.makeText(this, "Current location not available", Toast.LENGTH_SHORT).show()
            true
        }

    }
    private fun displaySavedObservations() {
        for (observation in observations) {
            val observationLocation = LatLng(observation.latitude, observation.longitude)
            mMap.addMarker(
                MarkerOptions()
                    .position(observationLocation)
                    .title(observation.speciesName)
                    .snippet("Observed at: ${observation.observationTime}")
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.my_observation_img))

            )
        }
    }
    //
    private fun centerMapOnLatestObservation() {
        if (observations.isNotEmpty()) {
            val latestObservation = observations.last()
            val observationLocation = LatLng(latestObservation.latitude, latestObservation.longitude)
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(observationLocation, 12f))
        }
    }



    // Handle permission request result
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_LOCATION_PERMISSION) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                onMapReady(mMap)
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

//added parameters
    private fun fetchHotspots(currentLat: Double, currentLng: Double) {
        val client = OkHttpClient()
        val url = "${Constants.EBIRD_HOTSPOTS_URL}?lat=$currentLat&lng=$currentLng&fmt=json" //removed static values
        val request = Request.Builder()
            .url(url)
            .addHeader("X-eBirdApiToken", Constants.EBIRD_API_KEY)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    val responseBody = response.body?.string()
                    if (responseBody != null) {
                        runOnUiThread {
                            addHotspotMarkers(responseBody)
                        }
                    }
                }
            }
        })
    }

    private fun addHotspotMarkers(responseBody: String) {
        val hotspots = JSONArray(responseBody)
        for (i in 0 until hotspots.length()) {
            val hotspot = hotspots.getJSONObject(i)
            val lat = hotspot.getDouble("lat")
            val lng = hotspot.getDouble("lng")
            val name = hotspot.getString("locName")

            val hotspotLocation = LatLng(lat, lng)
            mMap.addMarker(
                MarkerOptions().position(hotspotLocation).title(name)
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.parrot)) // Changes made here: Added custom parrot icon for hotspot markers
            )
        }
    }

    private fun fetchRoute(currentLat: Double, currentLng: Double, destinationLat: Double, destinationLng: Double) {
        val client = OkHttpClient()
        val url = "${Constants.DIRECTIONS_API_URL}?origin=$currentLat,$currentLng&destination=$destinationLat,$destinationLng&key=${Constants.GOOGLE_MAPS_API_KEY}"

        val request = Request.Builder().url(url).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    val responseBody = response.body?.string()
                    if (responseBody != null) {
                        runOnUiThread {
                            drawRoute(responseBody)
                        }
                    }
                }
            }
        })
    }

    private fun drawRoute(responseBody: String) {
        val json = JSONObject(responseBody)
        val routes = json.getJSONArray("routes")
        if (routes.length() > 0) {
            val points = routes.getJSONObject(0)
                .getJSONObject("overview_polyline")
                .getString("points")

            val polylineOptions = PolylineOptions()
            polylineOptions.addAll(PolyUtil.decode(points))
            polylineOptions.width(12f)
            polylineOptions.color(Color.MAGENTA)
            polylineOptions.geodesic(true)
            mMap.addPolyline(polylineOptions)
            // Changes made here: Set polyline properties (width, color) to enhance route visibility
        }
    }
}
