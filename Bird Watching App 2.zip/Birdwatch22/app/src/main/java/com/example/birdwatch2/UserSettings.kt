package com.example.birdwatch2

data class UserSettings(
    val useMetric: Boolean = true,      // Metric or Imperial system
    val maxDistance: Int = 10           // Maximum distance user is willing to travel
)
