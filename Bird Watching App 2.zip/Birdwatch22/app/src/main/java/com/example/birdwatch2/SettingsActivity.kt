package com.example.birdwatch2

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.Toast // Changes made here: Added Toast import for map loading feedback
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class SettingsActivity : AppCompatActivity() {

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private lateinit var metricSwitch: Switch
    private lateinit var maxDistanceEditText: EditText
    private lateinit var saveSettingsButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        metricSwitch = findViewById(R.id.metricSwitch)
        maxDistanceEditText = findViewById(R.id.maxDistanceEditText)
        saveSettingsButton = findViewById(R.id.saveSettingsButton)

        // Load existing settings when activity starts
        loadSettings()

        saveSettingsButton.setOnClickListener {
            val useMetric = metricSwitch.isChecked
            val maxDistance = maxDistanceEditText.text.toString().toIntOrNull() ?: 10 // Default to 10 if input is invalid

            // Save settings to Firebase
            saveSettings(useMetric, maxDistance)
        }
    }

    private fun loadSettings() {
        val user = FirebaseAuth.getInstance().currentUser
        val userId = user?.uid

        userId?.let {
            val firestore = FirebaseFirestore.getInstance()
            firestore.collection("users").document(it)
                .collection("settings").document("userSettings")
                .get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val useMetric = document.getBoolean("useMetric") ?: true
                        val maxDistance = document.getLong("maxDistance")?.toInt() ?: 10

                        metricSwitch.isChecked = useMetric
                        maxDistanceEditText.setText(maxDistance.toString())
                    }
                }
                .addOnFailureListener { e ->
                    Log.w("SettingsActivity", "Error loading settings", e)
                }
        }
    }

    private fun saveSettings(useMetric: Boolean, maxDistance: Int) {
        val user = FirebaseAuth.getInstance().currentUser
        val userId = user?.uid

        userId?.let {
            val firestore = FirebaseFirestore.getInstance()
            val settings = hashMapOf(
                "useMetric" to useMetric,
                "maxDistance" to maxDistance
            )

            firestore.collection("users").document(it)
                .collection("settings").document("userSettings")
                .set(settings)
                .addOnSuccessListener {
                    Log.d("SettingsActivity", "Settings successfully saved!")
                    Toast.makeText(this, "Settings saved!", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { e ->
                    Log.w("SettingsActivity", "Error saving settings", e)
                }
        }
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("useMetric", useMetric) // Boolean: true for metric, false for imperial
        intent.putExtra("maxDistance", maxDistance) // Int: The max distance in kilometers or miles
        startActivity(intent)
    }
}


