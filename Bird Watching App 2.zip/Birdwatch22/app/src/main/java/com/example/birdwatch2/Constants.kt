package com.example.birdwatch2

object Constants {
    const val EBIRD_API_KEY = "tko6u6n6ji6a"
    const val EBIRD_HOTSPOTS_URL = "https://api.ebird.org/v2/ref/hotspot/geo"
    const val DIRECTIONS_API_URL = "https://maps.googleapis.com/maps/api/directions/json"
    const val GOOGLE_MAPS_API_KEY = "AIzaSyD8zM608Lgfndfu1fKAMblVArFCwjWAitg"
}
