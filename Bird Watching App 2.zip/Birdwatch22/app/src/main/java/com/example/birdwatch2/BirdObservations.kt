package com.example.birdwatch2

import android.os.Parcel
import android.os.Parcelable

data class BirdObservations(
    val speciesName: String = "",
    val observationTime: Long = 0L,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readLong(),
        parcel.readDouble(),
        parcel.readDouble()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(speciesName)
        parcel.writeLong(observationTime)
        parcel.writeDouble(latitude)
        parcel.writeDouble(longitude)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<BirdObservations> {
        override fun createFromParcel(parcel: Parcel) = BirdObservations(parcel)
        // Changes made here: Simplified 'createFromParcel' method for better readability

        override fun newArray(size: Int): Array<BirdObservations?> = arrayOfNulls(size)
    }
}
